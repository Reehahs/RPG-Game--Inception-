import hsa.Console;
public class Enemy{ 
  private int magic; //Is the magic damage of the boss
  private int ranged; //Is the ranged damage of the boss
  private int melee; //Is the melee damage of the boss
  private int defense; //Is the type of defense that the first boss has 
  private double health; //Is the health value of the boss
  private int attackType; //Is the attack type of the first boss;
  private String name; //Is the name of the Boss;
  private double totalHealth; //this is the total health of the boss
 //Constructor 
  public Enemy(String bossName,int meleeDmg,int rangedDmg,int magicDmg,int armor,double hp){ //Intializes the boss
    magic=magicDmg;
    melee=meleeDmg;
    ranged=rangedDmg;
    defense=armor;
    health=hp;
    totalHealth=hp;
    attackType=0;
    name=bossName;
  }

  //Methods
  public double attack(int type){ //This returns the damamge value of your attack based of the actual attack the boss does;
    double dmg=0.0;//Stores the damage which is returned 
    double hitChance=0.0; //Used to calculating the chance of it hitting or missing
    if (type==1){  //RockThrow done by the first Boss
      dmg=melee+(ranged*0.7);
      hitChance=Math.random()*10;
      attackType=2;
      if (hitChance<3.0)
        return 0.0;
      else
        return dmg;
    }
    else if (type==2){ //FireBomb done by the second boss
      dmg=magic*1.5;
      hitChance=Math.random()*10;
      attackType=3;
      if (hitChance<4.0)
        return 0.0;
      else
        return dmg;
    }
    else if (type==3){ //WaterBolt done by the third boss
      dmg=magic+ranged;
      attackType=2;
      return dmg;
    }
    else if (type==4){ //Metal Smash done by the fourth boss 
      dmg=melee*3;
      hitChance=Math.random()*10;
      attackType=1;
      if (hitChance<7.0)
        return 0.0;
      else 
        return dmg;
      }
    else if (type==5){ //Void done by the final boss 
      dmg=magic;
      attackType=3;
      hitChance=Math.random()*10;
      if (hitChance<1.0)
        return 0.0;
      else
        return dmg;
    }
    else
      return 0.0;
  }
  
  
   public void takeDmg(int type, double dmg,Console c){ //This method calculates the damage the enemy takes and changes the health accordingly.
    if (type==1){ //If the attack type is a melee type
      if (defense==1){ //If the user is wearing melee armor it lessens the dmg dealt to the user
        health=health-(Math.round((dmg*0.75)*100)/100);
        c.println("\n"+name+" has slightly resisted this attack\n");
      }
      else if (defense==4){ //If the user is wearing enhanced melee armor it lessens the dmg dealt to the user even more
        health=health-(Math.round((dmg*0.5)*100)/100);
        c.println("\n"+name+" has resisted this attack\n");
      }
      else{
        health=health-dmg;
      }
    }
    else if (type==2){ //If the attack is a ranged type
      if (defense==2){ //If the user is wearing ranged armor it lessens the dmg dealt to the user
        health=health-(Math.round((dmg*0.75)*100)/100);
        c.println("\n"+name+" has slightly resisted this attack\n");
      }
      else if (defense==5){//If the user is wearing enhanced ranged armor it lessens the dmg dealt to the user even more
        health=health-(Math.round((dmg*0.5)*100)/100);
        c.println("\n"+name+" has resisted this attack\n");
      }
      else{
        health=health-dmg;
      }
    }
    else if (type==3){ //If the attack is a magic type
      if (defense==3){ //If the user is wearing magic armor it lessens the dmg dealt to the user
        health=health-(Math.round((dmg*0.75)*100)/100);
        c.println("\n"+name+" has slightly resisted this attack\n");
      }
      else if(defense==6){//If the user is wearing enhanced magic armor it lessens the dmg dealt to the user even more
        health=health-(Math.round((dmg*0.5)*100)/100);
        c.println("\n"+name+" has resisted this attack\n");
      }
      else{
        health=health-dmg;
      }
    }
    else
      health=health-dmg;
  }
  
  public double getHealth(){ //returns the health of the boss
    return health;
  }
  
  public double getTotalHealth(){ //returns the total health of the boss
    return totalHealth;
  }
  
  public int getType(){ //returns the type of attack it has just done
    return attackType;
  }
  
  public String getName(){ //returns the name of the boss
    return name;
  }
  

  
  
  
}
  
    