//Shaheer Khan
//Inception 
//13/05/2018
//Rpg in which you customize a character and go through 5 worlds killing the champion of each world and eventaully saving the galaxy. 
import hsa.Console;
import javax.imageio.*;  
import java.awt.*;
import java.io.*;

public class inceptionMainGame
{
  static Console c;
  public static void main(String[] args)//throws IOException //Main Method
  {
    //Consoles
    Console d;
    c=new Console(); 
    d=new Console(25,120);
    
    //Variables
    Image img; //The image to draw things onto the screen like sfx or things which arent drawn repeatdly
    Image avatar=importImg("avatar.jpg"); //The main avatar's image
    Image world=importImg("worlds.png"); //The 5 world's image
    String userName; //The name of the player
    String armor; //The armor which the player chooses in the beggining of the game
    int defense; //The armors number
    int adaptiveArmor=(int)((Math.random()*3)+3); //the adaptive armor made for the final boss
    int[] stats= new int[3]; //The stats value of the player in an array.
    Enemy gearth=new Enemy("Stone Golem",10,10,0,2,120); //Intializes the different bosses, first boss
    Enemy sarm= new Enemy("Pheonix",0,0,30,3,150); //second boss
    Enemy plubo= new Enemy("Hydra",0,25,15,2,250); //third boss
    Enemy metallica= new Enemy("Crystaloid",45,0,0,adaptiveArmor,450.0); //fourth boss
    
    //Main game
    //Introduction--------------------------------------------------------------------------------------------------------------------
    img=importImg("welcomeToInception.png");
    d.drawImage(img,20,20,null);
    d.readLine();
    c.println("Welcome to the game of Inception, \nWhere you must go and fight the 5 rulers of the galaxy and take over the throne!");
    c.println("What is your name young warrior");
    userName=c.readLine(); //Gets the players name
    c.clear();
    c.println("Ahh welcome to Inception " +userName);
    img=importImg("differentSkills.png");
    d.drawImage(img,20,20,null);
    
    //Makes the player pick their begging stats-------------
    stats=statsDistrubuter(30,0,0,0);
    c.println("\nYou have succesfully chosen your stats!");
    
    //Creating the main player object------------------------
    Player p=new Player(userName,stats[0],stats[1],stats[2]);
    img=importImg("differentArmors.png");
    d.drawImage(img,10,20,null);
    
    //Makes the player pick armor-----------------------------------------------------------------------
    c.println("\nWhat armor do you want to equip!\nYou can't head of into battle without armor!");
    c.println("\nThere are 3 types of armor, each effective for blocking a specfic type of attack");
    c.println("\nThere is Iron Armor which is effective at blocking Melee dmg!");
    c.println("There is Leather Tunic which is effective at blocking Ranged dmg!");
    c.println("There is Mage Robes which is effective at blocking Magic dmg!");
    //This data validation makes sure you select you pick one of the three armor 
    while (true){  
      try{
        c.println("\nWhich armor would you like to choose?:");
        c.print("\nEnter 1 for Iron Armor,or enter 2 for Leather Tunic, or enter 3 for Mage Robe:");
        armor=c.readString();
        defense=Integer.parseInt(armor);
        if (defense>=1 && defense<=3) //Makes sure you pick either 1,2,or 3
          break;
        else
          c.println("\n\nMake sure you input 1,2,or 3! Nothing else!");
      }
      catch (NumberFormatException e){
        c.println("\n\nOnly input an integer number either 1,2,or 3 only :) ");
      }
    }
    p.chooseArmor(defense); //selects your armor
    c.println("\nAhhh wise choice indeed my fellow");
    c.print("\nNow are you ready for adventure? Press enter twice to get started:");
    c.readLine();
    d.close();
    c.clear(); 
    
    //Draws images on the console of the world and player and tells a little bit of the background story 
    d=new Console(30,125); //(y/x)
    img=importImg("story.png");
    d.drawImage(img,20,20,null); //Draws the story on the screen for player to read
    d.drawImage(avatar,98,460,null);
    d.setCursor(27,25);
    d.println("<---- THIS IS YOU.   You wear a hood over your armor because your just that cool. Enter 1 to Continue:");
    d.setCursor(28,25);
    d.readInt();
    d.clear();
    d.drawImage(world,30,25,null); //draws the world image onto the screen
    avatar=importImg("avatar.jpg"); //had to reintialize because of a glitch of the avatar going black 
    d.drawImage(avatar,98,80,null);
    d.setCursor(8,25);
    d.println("You are in Gearth would you like to fight the boss for world 1? Press enter twice to start the fight:");
    d.readLine();
    d.clear();
    
    //THE FIRST BOSS BATTLE----------------------------------------------------
    battle(p,gearth,"stoneGolem.png",1,d);
    if (p.getHealth()<=0){
      c.println("You have died, game over");
      c.println("Press enter twice to end game");
      c.readLine();
      System.exit(0);
    }
    else
      c.println("CONGRATS YOU KILL THE STONE GOLEM!");
    
    //Rewarded for the win 
    c.println("Congrats, you beat Gearth you recieve: \n+5 Health Pot (Heals +20 each)\n+1 ChugJug (Gives +5 stats permanent)\n");
    p.chooseItem(1,5);
    p.chooseItem(2,1);
    c.println("You also recived +10 stat point!!\n");
    stats=p.getStats();
    stats=statsDistrubuter(10,stats[0],stats[1],stats[2]);
    p.levelUp(stats);
    p.resetHealth();
    c.print("\nPress enter twice to continue:");
    c.readLine();
    
    //Draws the second world after the first boss
    d.clear();
    d.drawImage(world,30,25,null); //draws the world image onto the screen
    avatar=importImg("avatar.jpg"); //had to reintialize because of a glitch of the avatar going black 
    d.drawImage(avatar,290,80,null);
    d.setCursor(8,50);
    d.print("You are in Sarm would you like to fight the boss for world 2?"); 
    d.setCursor(9,50);
    d.print("Press enter twice to start the fight:");
    d.readLine();
    d.clear();
    c.clear();
    
    //THE SECOND BOSS BATTLE----------------------------------------------------
    battle(p,sarm,"pheonix.png",2,d); 
    if (p.getHealth()<=0){ //Determines victor
      c.println("You have died, game over");
      c.println("Press enter twice to end game");
      c.readLine();
      System.exit(0);
    }
    else{
      c.println("CONGRATS YOU KILLED PHEONIX!");
      c.println("Press enter twice to continue");
      c.readLine();
    }
    
    //Rewarded for the win against Pheonix
    c.println("Congrats, you beat Pheonix you recieve: \n+5 Health Pot (Heals +20 each)\n+1 Smiths Hammer! (Grants permanent Armor Upgrade!)\n");
    p.chooseItem(1,5);
    p.chooseItem(3,1);
    c.println("You also recived +10 stat point!!\n");
    stats=p.getStats();
    stats=statsDistrubuter(10,stats[0],stats[1],stats[2]);
    p.levelUp(stats);
    p.resetHealth();
    c.print("\nPress enter twice to continue:");
    c.readLine();
    
    //Draws the third world after the second boss
    d.clear();
    d.drawImage(world,30,25,null); //draws the world image onto the screen
    avatar=importImg("avatar.jpg"); //had to reintialize because of a glitch of the avatar going black 
    d.drawImage(avatar,500,80,null);
    d.setCursor(23,50);
    d.print("You are in Plubo would you like to fight the boss for world 3?"); 
    d.setCursor(24,70);
    d.print("Press enter twice to start the fight:");
    d.readLine();
    d.clear();
    c.clear();
        
    //THE THIRD BOSS BATTLE----------------------------------------------------
    battle(p,plubo,"BlueDragon.png",3,d);
    //checks to see who won 
    if (p.getHealth()<=0){
      c.println("You have died, game over");
      c.println("Press enter twice to end game");
      c.readLine();
      System.exit(0);
    }
    else{
      c.println("CONGRATS YOU KILLED HYRDRA!");
      c.println("Press enter twice to continue");
      c.readLine();
    }
    
    //Rewards the player for defeating hydra!
    c.println("Congrats, you beat Hyrdra you recieve: \n+2 ChugJug (Gives +5 stats permanent)\n");
    p.chooseItem(2,2);
    c.println("You also recived +20 stat point!!\n");
    stats=p.getStats();
    stats=statsDistrubuter(20,stats[0],stats[1],stats[2]);
    p.levelUp(stats);
    p.levelUp(stats);
    p.resetHealth();
    c.print("\nPress enter twice to continue:");
    c.readLine();
    
    //Draws the fourth world after the third boss
    d.clear();
    d.drawImage(world,30,25,null); //draws the world image onto the screen
    avatar=importImg("avatar.jpg"); //had to reintialize because of a glitch of the avatar going black 
    d.drawImage(avatar,650,80,null);
    d.setCursor(23,50);
    d.print("You are in Metallica would you like to fight the boss for world 4?"); 
    d.setCursor(24,50);
    d.print("Press enter twice to start the fight:");
    d.readLine();
    d.clear();
    c.clear();
    
    //THE FOURTH BOSS BATTLE----------------------------------------------------
    battle(p,metallica,"CrystalGolem.png",4,d);
    //checks to see who won 
    if (p.getHealth()<=0){
      c.println("You have died, game over");
      c.println("Press enter twice to end game");
      c.readLine();
      System.exit(0);
    }
    else{
      c.println("CONGRATS YOU KILLED CRYSTALOID!");
      c.println("Press enter twice to continue");
      c.readLine();
    }
    
    //Rewards the player for defeating Crystaloid!
    c.println("Congrats, you beat Crystal you recieve: \n+2 ChugJug (Gives +5 stats permanent)\n");
    p.chooseItem(2,2);
    c.println("You also recived +20 stat point!!\n");
    stats=p.getStats();
    stats=statsDistrubuter(20,stats[0],stats[1],stats[2]);
    p.levelUp(stats);
    p.resetHealth();
    c.print("\nPress enter twice to continue:");
    c.readLine();
     
    //Draws the final world after the fourth boss
    d.clear();
    d.drawImage(world,30,25,null); //draws the world image onto the screen
    avatar=importImg("avatar.jpg"); //had to reintialize because of a glitch of the avatar going black 
    d.drawImage(avatar,850,80,null);
    d.setCursor(23,50);
    d.print("You are at DEATH STAR would you like to fight the final boss"); 
    d.setCursor(24,50);
    d.print("Press enter twice to start the fight:");
    d.readLine();
    d.clear();
    c.clear();
    
    //determines what stat the user has maxed out in order to give the final boss adaptive armor otherwise it sticks with the adaptiveArmor value randomed in the beggining
    if (stats[0]>stats[1] && stats[0]>stats[2])
      adaptiveArmor=4;
    else if (stats[1]>stats[0] && stats[1]>stats[2])
      adaptiveArmor=5;
    else if (stats[2]>stats[0] && stats[2]>stats[1])
      adaptiveArmor=6;
    
    Enemy deathStar= new Enemy("El Nazereth",0,0,65,adaptiveArmor,500); //Final Boss 
    //THE FINAL BOSS EL NAZERETH-----------------------------
    battle(p,deathStar,"ElNazereth.jpg",5,d);
   
    
    //checks to see who won 
    if (p.getHealth()<=0){
      c.println("You have died, game over");
      c.println("Press enter twice to end game");
      c.readLine();
      System.exit(0);
    }
    else{
      c.println("CONGRATS YOU KILLED El Nazereth!");
      c.println("Press enter twice to continue");
      c.readLine();
    }
    
    //If the user wins and finishes the game
    c.clear();
    d.clear();
    c.println("YOU HAVE BEAT THE GAME CONGRATSS, I MADE IT KINDA HARD, YOU HAD TO USE STRATEGY!!!! AND A BUNCH OF RETRYIES :)");
    c.println("Congrats "+p.getName()+" you have saved the galaxy from the 5 tyrants!!!!");
    c.println("Press enter twice to end the game");
    c.readLine();
    System.exit(0);
    
    
    
    
    
    
    
    
  }
  
  
  
  
  
  
  //Methods
    
  //In this method the entire battle takes place determining the eventual winner. 
  public static void battle(Player p, Enemy boss, String bossImage,int bossNumber, Console d){
    //Variables 
    double userDmg; //The damage the player deals with each turn
    double compDmg; //The damage the comp deals with each turn 
    double userHealth; //The players health 
    double enemyHealth; //The enemies health
    double percent=1; //The perecent health of dmg dealt to the player
    double compPercent=1; //The percent health of dmg dealt to the enemy
    int width=150; //The width of the health bar
    int compWidth=150; //The width of the enemy health bar
    Image avatar=importImg("avatar.jpg"); //The main avatar's image
    Image battleScene=importImg("battleScene.png"); //The scene which comes when the user enters a battle
    Image enemyAvatar=importImg(bossImage); //The fourth boss    
    
    //This loop goes on for as long as the battle isn't over
    while (p.getHealth()>0 && boss.getHealth()>0){ 
      
      //draws the scene out
      d.drawImage(battleScene,10,10,null);
      d.drawImage(enemyAvatar,600,175,null);
      d.drawImage(avatar,70,200,null);
      drawStats(p.getStats(),p.getName(),d);
      drawCurrentHp(2,boss.getHealth(),boss.getTotalHealth(),d);
      drawCurrentHp(1,p.getHealth(),p.getTotalHealth(),d);
      
      //Gets user input for which attack they want and does it, updates the health bar
      userDmg=userAttack(bossImage,p,d); 
      enemyHealth=boss.getHealth();
      boss.takeDmg(p.getType(),userDmg,c);
      compPercent=healthBarChanger(enemyHealth,boss.getHealth(),userDmg);
      drawCurrentHp(2,boss.getHealth(),boss.getTotalHealth(),d);
      compWidth=(int)(Math.round(healthBar(2,compWidth,compPercent,d)));
      
      if (boss.getHealth()<=0){ // to check if the enemy isn't dead after the attack because if its dead it shouldn't get a chance to attack back 
        drawCurrentHp(2,0,boss.getTotalHealth(),d);
        drawCurrentHp(1,p.getHealth(),p.getTotalHealth(),d);
        compWidth=(int)(Math.round(healthBar(2,0,1,d)));
        width=(int)(Math.round(healthBar(1,width,1,d)));
        d.drawImage(enemyAvatar,600,175,null);
        d.drawImage(avatar,70,200,null);
        drawStats(p.getStats(),p.getName(),d);
        break;
      }
      compDmg=boss.attack(bossNumber); //The computer attacks
      if(compDmg==0){ //if the computer misses its attack 
        c.println(boss.getName()+" has missed its attack!!");
        userHealth=p.getHealth();
        percent=healthBarChanger(userHealth,p.getHealth(),compDmg);
        width=(int)(Math.round(healthBar(1,width,percent,d)));
        drawCurrentHp(1,p.getHealth(),p.getTotalHealth(),d);
        d.drawImage(enemyAvatar,600,175,null);
        d.drawImage(avatar,70,200,null);
        drawStats(p.getStats(),p.getName(),d);
        c.println("Press enter twice to continue");
        c.readLine();
      } 
      else{ //if the user does dmg to the player
        c.println(boss.getName()+" has done "+compDmg+" damage!");
        userHealth=p.getHealth();
        p.takeDmg(boss.getType(),compDmg,c);
        percent=healthBarChanger(userHealth,p.getHealth(),compDmg);
        drawCurrentHp(1,p.getHealth(),p.getTotalHealth(),d);
        compAttackAnimation(bossNumber,d);
        d.drawImage(enemyAvatar,600,175,null);
        d.drawImage(avatar,70,200,null);
        drawStats(p.getStats(),p.getName(),d);
        width=(int)(Math.round(healthBar(1,width,percent,d)));
        c.println("Press enter twice to continue");
        c.readLine();
      }
    }
  }
  
  
  //This method is used whenever the character levels up and is allocating their points for leveling up
  public static int[] statsDistrubuter(int statAmount,int meleeDmg,int rangedDmg, int magicDmg){ 
    int totalStatPoints; //checks to see if the player has used all of their points
    String melee; //The melee dmg stat of the player
    String ranged; //The ranged dmg stat of the player 
    String magic; //The magic dmg stat of the player
    int[] stats=new int[3]; //The stats will be saved in this array variable
    
    while (true){  //This data validation makes sure you select your stats properly so you don't break the game!
      try{
        c.println("\nYou now have +"+statAmount+" points! \nDivide your "+statAmount+" points within the 3 stats as you would wish!");
        c.println("The three stats to pick between are Melee, Ranged, and Magic.\nEach have their own weaknesses and strengths! Choose wisely."); //Makes you select your stats
        totalStatPoints=statAmount;
        c.print("You currently have "+totalStatPoints+" points to spend:");
        c.print("\nHow many levels would you like to put in Melee: ");
        melee=c.readLine();
        stats[0]=(Integer.parseInt(melee))+meleeDmg; //updates melee stat
        totalStatPoints=totalStatPoints-(Integer.parseInt(melee));
        c.print("\nYou currently have "+totalStatPoints+" points to spend:");
        c.print("\nHow many levels would you like to put in Ranged: ");
        ranged=c.readLine();
        stats[1]=(Integer.parseInt(ranged))+rangedDmg;//updates ranged stat
        totalStatPoints=totalStatPoints-(Integer.parseInt(ranged));
        c.print("\nYou currently have "+totalStatPoints+" points to spend:");
        c.print("\nHow many levels would you like to put in Magic: ");
        magic=c.readLine();
        stats[2]=(Integer.parseInt(magic))+magicDmg;//updates magic stat
        totalStatPoints=(Integer.parseInt(magic))+(Integer.parseInt(ranged))+(Integer.parseInt(melee));
        if (totalStatPoints==statAmount)
          break;
        else
          c.println("\nMake sure you only have "+statAmount+" points total! No less, No more!");
      }
      catch (NumberFormatException e){
        c.println("Only input an integer number from 0-"+statAmount+" please :) ");
      }
    }
    return stats;
  }
  
  //This method just checks that an image can be imported
  public static Image importImg(String imageName){ //This method tries to import the image from the folder that I stored them in
    Image img;
    try{
      img = ImageIO.read(new File("Graphic//"+imageName));
    }
    catch(IOException e){  //if file not found
      img = null;
    }
    return img;
  }

  //This method checks to see what attack the user does
  public static int attackDeterminer(int x, int y){
    int attack=0; 
    if (x==1){  //The the user attacks
      if (y==1){ //if the user uses stab
        attack=1;
        
      }
      else if(y==2){ //if the user uses throwing knife
        attack=2;
        
      }
    }
    else if (x==2){ //if the user uses skill
      if (y==1){ //if the user used fireball
        attack=3;
        
      }
      else if (y==2){ //if the user uses windstrike
        attack=4;
        
      }
    }
    else if (x==3){//if the user uses an item
      if (y==1){//if the user user a healthpot
        attack=5;
        
      }
      else if (y==2){//if the user uses a CHUGJUG
        attack=6;
        
      }
      else if (y==3){//if the user uses a Smith's Hammer
        attack=7;
        
      }
    }
    return attack;
    
  }
  
  //This is the method which determines all user descions when a fight occurs in the battle method 
  public static double userAttack(String bossName,Player p,Console d){
    
    //Variables
    String choice;//This is the string where they input the string to be data validated 
    int choice1; //The first choice of attack type the user makes when in battle
    int choice2=4; //The second choice of attack type the user makes when in battle
    int attack; //This is the attack they do
    double userDmg=0.0; //This is the damage the user does
    Image avatar=importImg("avatar.jpg");
    Image battleScene=importImg("battleScene.png"); //The scene which comes when the user enters a battle
    Image battleScene1=importImg("battleScene1.png"); //The scene after the user selects to attack
    Image battleScene2=importImg("battleScene2.png");//The scene after the user selects to use a skill
    Image battleScene3=importImg("battleScene3.png"); //The scene after the user selects to use an item
    Image boss=importImg(bossName);
    int [] items=new int[3]; //The amount of items 
    
    //The player gets to make the first action
    do{ //4 is used as a backspace to go back to be able to select choose the main choice again 
      //draws the battle scene
      d.drawImage(battleScene,10,10,null);
      d.drawImage(boss,600,175,null);
      d.drawImage(avatar,70,200,null);
      drawStats(p.getStats(),p.getName(),d);
      drawCurrentHp(1,p.getHealth(),p.getTotalHealth(),d);
      
      while (true){ //To determine the action that the user would like to do
        try{ 
          c.println("Enter 1 to Attack. Enter 2 to use a Spell. Enter 3 to use an Item."); //The first choice
          choice=c.readLine();
          choice1=Integer.parseInt(choice);
          if (choice1>=1 && choice1<=3)
            break;
          else
            c.println("Input a number between 1-3\n");
        }
        catch(NumberFormatException e){
          c.println("Only input 1, 2, 3 to do one of the choices.\n");
        }
      }
      
      if (choice1==1){ //If the user decides to attack
        d.drawImage(battleScene1,10,10,null);
        d.drawImage(boss,600,175,null);
        d.drawImage(avatar,70,200,null);
        drawStats(p.getStats(),p.getName(),d);
        drawCurrentHp(1,p.getHealth(),p.getTotalHealth(),d);
        while (true){ //makes sure the user only input on of the available choices
          try{
            c.println("Enter 1 to Stab. Enter 2 to use Throwing Knifes. Enter 4 to go back");
            choice=c.readLine();
            choice2=Integer.parseInt(choice);
            if (choice2>=1 && choice2<=2 || choice2==4)
              break;
            else
              c.println("Input a number between 1-2 or 4 to go back\n");
          }
          catch(NumberFormatException e){
            c.println("Only input 1, 2, or 4 to do one of the choices.\n");
          }
        }
      }
      else if (choice1==2){ // If the user decides to use a Skill 
        d.drawImage(battleScene2,10,10,null);
        d.drawImage(boss,600,175,null);
        d.drawImage(avatar,70,200,null);
        drawStats(p.getStats(),p.getName(),d);
        while (true){//makes sure the user only input on of the available choices
          try{
            c.println("Enter 1 to use Fireball. Enter 2 to use Wind Strike. Enter 4 to go back");
            choice=c.readLine();
            choice2=Integer.parseInt(choice);
            if (choice2>=1 && choice2<=2 || choice2==4)
              break;
            else
              c.println("Input a number between 1-2\n");
          }
          catch(NumberFormatException e){
            c.println("Only input 1,2, or 4 to do one of the choices.\n");
          }
        }
      }
      else if (choice1==3){ //if the user decided to use an Item
        d.drawImage(battleScene3,10,10,null);
        d.drawImage(boss,600,175,null);
        d.drawImage(avatar,70,200,null);
        drawStats(p.getStats(),p.getName(),d);
        drawCurrentHp(1,p.getHealth(),p.getTotalHealth(),d);
        while (true){ //makes sure the user only input on of the available choices
          try{
            c.println("Enter 1 to use Heal Potion. Enter 2 to use ChugJug. Enter 3 to use Smith's Hammer. Enter 4 to go back");
            choice=c.readLine();
            choice2=Integer.parseInt(choice);
            if (choice2>=1 && choice2<=3 || choice2==4)
              break;
            else
              c.println("Input a number between 1-3\n");
          }
          catch(NumberFormatException e){
            c.println("Only input 1,2,or 3 to do one of the choices.\n");
          }
        }
      }
      //After getting the descions of the user this method determines what to do depending on the two of the user.
      attack=attackDeterminer(choice1,choice2);
      
      if (attack>=5 && attack<=7){ //If the action is an item use
        items=p.getItem();
        if ((items[attack-5])==0){ //If the item is not available
          choice2=4;
          c.println("That item is not available!!");
        }
        else{ //If the item is availaibe this uses it.
          p.useItem(attack, c);
        }
      }
      
      else{ //If the action is an actual attack and not an item use
        userDmg=p.attack(attack); 
        if (userDmg==0){
          c.println("\nOh No!! You missed!");
          c.println("Press enter twice to continue");
          c.readLine();
        }
        else if (userDmg>0){
          c.print("\nYou just dealt ");
          c.print(userDmg,0,2);
          c.println(" damage");
          userAttackAnimation(attack,d);
          c.println("Press enter twice to continue");
          c.readLine();
        }
      }     
    }while (choice2==4);
    
    //redraws the scene after for the comp to be able to do its animations and stuff
    d.drawImage(boss,600,175,null);
    d.drawImage(avatar,70,200,null);
    d.drawImage(battleScene,10,10,null);
    drawStats(p.getStats(),p.getName(),d);
    drawCurrentHp(1,p.getHealth(),p.getTotalHealth(),d);
    return userDmg;
  }
  
  public static void drawStats(int stats[], String userName, Console d){ //shows the players stat on the battle screen for a more user friendly output
    d.setCursor(8,12); 
    d.print(userName);
    d.setCursor(26,6);
    d.print("Melee: "+stats[0]);
    d.setCursor(27,6);
    d.print("Ranged: "+stats[1]);
    d.setCursor(28,6);
    d.print("Magic: "+stats[2]);
  }
  
  public static void drawCurrentHp(int user,double health, double totalHealth, Console d){ //This shows the user his/her current health
    if (user==1){
     d.setCursor(24,15);
     d.print("Hp: "+health+"/"+totalHealth);
    }
    else if(user==2){
     d.setCursor(24,61);
     d.print("Hp: "+health+"/"+totalHealth);
    }
  }
  
  public static double healthBar(int user,int width,double percent, Console d){ //This draws the health bar of the user and comp.
    
    if (user==1){
      width=(int)(Math.floor(width*percent));
      d.setColor(Color.black);
      d.drawRect(80,480,150,15);
      d.setColor(Color.green);
      d.fillRect(80,480,width,15);
    }
    else if(user==2){
      width=(int)(Math.floor(width*percent));
      d.setColor(Color.black);
      d.drawRect(380,480,150,15);
      d.setColor(Color.green);
      d.fillRect(380,480,width,15);
    }
    return width;
  }
  
  public static double healthBarChanger(double healthPrior,double health, double dmg){ //figures out the percent health was damaged so that percent can be applied onto the x value of the fillRect giving it the precise change
    double percent=1;
    if (healthPrior==(health+dmg))
      percent=(healthPrior-dmg)/healthPrior;
    else if (healthPrior==(health+(Math.round((dmg*0.75)*100)/100))) //if they have armor which resists
      percent=(healthPrior-(Math.round((dmg*0.75)*100)/100))/healthPrior;
    else if (healthPrior==(health+(Math.round((dmg*0.5)*100)/100))) //if they have upgraded armor which resists
      percent=(healthPrior-(Math.round((dmg*0.5)*100)/100))/healthPrior;
    
    return percent;
  }

  
  public static void userAttackAnimation(int attack,Console d){ //This displays the cool attack images for the user's attack
    Image img;
    if (attack==1){
      img=importImg("stabAttack.png");
      d.drawImage(img,500,200,null);
    }
    if (attack==2){
      img=importImg("knife.png");
      d.drawImage(img,500,200,null);
      d.drawImage(img,450,200,null);
      d.drawImage(img,400,200,null);
    }
    if (attack==3){
      img=importImg("fireBall.png");
      d.drawImage(img,400,200,null);
    }
    if (attack==4){
      img=importImg("windStrike.jpg");
      d.drawImage(img,370,200,null);
    }
  }
  
  public static void compAttackAnimation(int attack, Console d){ //this displays the cool attack for the computer's attack
    Image img;
    if (attack==1){
      img=importImg("rock.png");
      d.drawImage(img,200,200,null);
    }
    if (attack==2){
      img=importImg("fireBomb.jpg");
      d.drawImage(img,200,230,null);
    }
    if (attack==3){
      img=importImg("waterbolt.jpg");
      d.drawImage(img,180,200,null);
    }
    if (attack==4){
      img=importImg("smash.jpg");
      d.drawImage(img,180,150,null);
    }
    if (attack==5){
      img=importImg("void.png");
      d.drawImage(img,200,150,null);
    }
  }
  
  
  
  
  
  
  
  
  
}