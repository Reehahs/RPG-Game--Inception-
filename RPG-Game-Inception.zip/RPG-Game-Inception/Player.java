import hsa.Console;
public class Player{ 
  private int magic; //Is the magic damage of the main player
  private int ranged; //Is the ranged damage of the main player
  private int melee; //Is the melee damage of the main player
  private int defense; //Is the type of armor which you choose which determines the main player
  private double health; //Is the health value of the main player during combat
  private double totalHealth; //is the total health of the player
  private int[]item=new int[3]; //Stores the choice of item the player picks
  private int attackType; //Is the attack type (magic, melee, ranged) the player chooses to do that turn;
  private String username; //Is the name of the player;
  
  
  //Constructor
  public Player(String userName, int meleeDmg,int rangedDmg,int magicDmg){
    magic=magicDmg;
    melee=meleeDmg;
    username=userName;
    ranged=rangedDmg;
    health=100.0;
    totalHealth=health;
    for (int x=0; x<3; x++){
      item[x]=0;
    }
    defense=0;
    attackType=0;
  }
  
  //Methods 
  public double attack(int type){ //This returns the damamge value of your attack based of the actual attack you do;
    double dmg=0.0;
    double hitChance=0.0;
    if (type==1){  //Stab  type:melee, but magic and ranged assist slightly 
      dmg=melee*1.2+(magic*0.5)+(ranged*0.2);
      hitChance=Math.random()*10;
      attackType=1;
      if (hitChance<1.0)
        return 0.0;
      else
        return dmg;
    }
    else if (type==2){ //Throwing knifes type ranged... magic and melee assists slightly 
      attackType=2;
      for (int x=0; x<3; x++){
        hitChance=Math.random()*10;
        if (hitChance<3.0){
          dmg=dmg+0.0; 
        }
        else{
          dmg=dmg+(ranged*0.60)+(magic*0.2)+(melee*0.3);
        }
      }
      return dmg;
    }
    else if (type==3){ //Fireball  type magic...ranged and melee assits
      dmg=magic*4.5+ranged*4+melee*2;
      attackType=3;
      hitChance=Math.random()*10;
      if (hitChance<8.0)
        return 0.0;
      else
        return dmg;
    }
    else if (type==4){ //WindStrike  type magic... melee and ranged assits
      dmg=magic*1.25+melee*0.2+ranged*0.5;
      hitChance=Math.random()*10;
      attackType=3;
      if (hitChance<2.0)
        return 0.0;
      else 
        return dmg;
      }
    else
      return -1.0;
  }
  
  public void takeDmg(int type, double dmg, Console c){ //This method calculates the damage the player takes and changes the health accordingly.
    if (type==1){ //If the attack type is a melee type
      if (defense==1){ //If the user is wearing melee armor it lessens the dmg dealt to the user
        health=health-(Math.round((dmg*0.75)*100)/100);
        c.println("\nYou have slightly resisted this attack\n");
      }
      else if (defense==4){ //If the user is wearing enhanced melee armor it lessens the dmg dealt to the user even more
        health=health-(Math.round((dmg*0.5)*100)/100);
        c.println("\nYou have resisted this attack\n");
      }
      else{
        health=health-dmg;
      }
    }
    else if (type==2){ //If the attack is a ranged type
      if (defense==2){ //If the user is wearing ranged armor it lessens the dmg dealt to the user
        health=health-(Math.round((dmg*0.75)*100)/100);
        c.println("\nYou have has slightly resisted this attack\n");
      }
      else if (defense==5){//If the user is wearing enhanced ranged armor it lessens the dmg dealt to the user even more
        health=health-(Math.round((dmg*0.5)*100)/100);
        c.println("\nYou have resisted this attack\n");
      }
      else{
        health=health-dmg;
      }
    }
    else if (type==3){ //If the attack is a magic type
      if (defense==3){ //If the user is wearing magic armor it lessens the dmg dealt to the user
        health=health-(Math.round((dmg*0.75)*100)/100);
        c.println("\nYou have slightly resisted this attack\n");
      }
      else if(defense==6){//If the user is wearing enhanced magic armor it lessens the dmg dealt to the user even more
        health=health-(Math.round((dmg*0.5)*100)/100);
        c.println("\nYou have resisted this attack\n");
      }
      else{
        health=health-dmg;
      }
    }
    else
      health=health-dmg;
  }
  
  public void resetHealth(){ //simply resets the user health after a battle
    health=totalHealth;
  }
  
  public void chooseArmor(int choice){ //When the player chooses the armor which they want to wield
    defense=choice;
  }
  
  public int getType(){ //returns the attack type 
    return attackType;
  }
  
  public String getName(){ //return the username
    return username;
  }
  
  public double getTotalHealth(){ //returns the total health
    return totalHealth;
  }
  
  public double getHealth(){ //return the health value
    return health;
  }
  
  public int getDefense(){ //Returns the user armor 
    return defense;
  }
  
  public void levelUp(int[] skill){ //when the character levels up and the player picks their skill to level up it levels that skill up plus health.
    for (int x=0;x<skill.length;x++){
      if (x==0){
        melee=skill[x];
      }
      else if (x==1){
        ranged=skill[x];
      }
      else if (x==2){
        magic=skill[x];
      } 
    }
    health=totalHealth+50;
    totalHealth=health;
    
  }
  
  public int[] getStats(){ //This just gets all the stats and puts it in an array for easy use for me
    int[] stats= new int[3];
    for (int x=0; x<3; x++){
      if (x==0){
        stats[x]=melee;
      }
      else if (x==1){
        stats[x]=ranged;
      }
      else if (x==2){
        stats[x]=magic;
      }
    }
    return stats;
  }
  
  public void chooseItem(int itemChoice,int amount){ //this saves the item which the player picks;
    item[itemChoice-1]=item[itemChoice-1]+amount;
  }
  
  public int[] getItem(){ //returns item amounts in an array
    return item;
  }

  public void useItem(int itemChoice,Console c){  //When the player wants to use and item
    if (itemChoice==5){ //The most common item, heals the player (Health pot)
      item[itemChoice-5]=item[itemChoice-5]-1;
      if ((health+50)>totalHealth){ //make sure the player does't heal too much health and goes over totalHealth
        double healAmount;
        healAmount=totalHealth-health;
        c.println("Yummm, you healed "+healAmount+"hp. ");
        health=health+healAmount;
      }
      else{
      c.println("Yummm, you healed 50hp. ");
      health=health+50;
      }
    }
    else if (itemChoice==6){ //Gives permanent damage stats (CHUGJUG)
      c.println("Yummm ,you gained +5 in all stats!");
      item[itemChoice-5]=item[itemChoice-5]-1;
      melee=melee+5; 
      ranged=ranged+5;
      magic=magic+5;
    }
    else if (itemChoice==7){
      c.println("WHATT YOUR ARMOR HAS BEEN UPGRADED!!!");
      item[itemChoice-5]=item[itemChoice-5]-1;
      if (defense==0)
        defense=0;
      else
        defense=defense+3; //Upgrade the armor, can only be done once in the game  (Smith's Hammer
     }
  }
}           
      
  
  
  
  
  
  
  
  

    
   